function setCountry(country, overallActions) {
    document.querySelector('.country_tag').innerHTML = country + " - Protests 1980-1995: " + overallActions;
}

function getChartData(countryName) {

    $.ajax({
	method: "get",
	url: "index.php", 
	data: {id: countryName},
	success: function(result, textStatus, jqXHR) {
            console.log(result);
            var actions = JSON.parse(result);
	    var annualActions = actions["annualActions"];
	    var overallActions = actions["overallActions"];
	    var barChartData = [annualActions[0],annualActions[1],annualActions[2],annualActions[3],
			    annualActions[4],annualActions[5],annualActions[6],annualActions[7],
			    annualActions[8],annualActions[9],annualActions[10],annualActions[11],
		            annualActions[12],annualActions[13],annualActions[14],annualActions[15]]
	    setCountry(countryName, overallActions);
	    populateCharts(barChartData);
	},
	error: function(jqXHR, textStatus, errorThrown) {
	    console.log(textStatus);
    }});
}

function populateCharts(barChartData) {
    console.log(JSON.stringify(barChartData));
    for (i = 0; i < 16; i++) {
        if (typeof barChartData[i] !== undefined && barChartData[i] != null) {
            window.myBar.datasets[0].bars[i].value = barChartData[i];
            window.myWideBar.datasets[0].bars[i].value = barChartData[i];
        } else {
            window.myBar.datasets[0].bars[i].value = 0;
            window.myBar.datasets[0].bars[i].value = 0;
        }
    }
    window.myBar.update();
    window.myWideBar.update();
}

function makeCharts() {
    var barChartData = {
	labels : ["1980","1981","1982","1983","1984","1985","1986","1987",
		  "1988","1989","1990","1991","1992","1993","1994","1995"],
	datasets : [
	    {
		fillColor : "rgba(220,220,220,0.5)",
		strokeColor : "rgba(220,220,220,0.8)",
		highlightFill: "rgba(220,220,220,0.75)",
		highlightStroke: "rgba(220,220,220,1)",
		data : ["0","0","0","0",
		    "0","0","0","0",
		    "0","0","0","0",
		    "0","0","0","0"]
	    }
	
	]
    }
    var ctx = document.getElementById("canvas").getContext("2d");
    window.myBar = new Chart(ctx).Bar(barChartData, {
	responsive : true
    });
    var ctx = document.getElementById("canvas_alt").getContext("2d");
    window.myWideBar = new Chart(ctx).Bar(barChartData, {
	responsive : true
    });
}
