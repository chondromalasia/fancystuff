<?php

        $host = "hex.cl.uzh.ch";
        $port = 65432;
        $dbname = "pcl3fancystuff";
        $user = "pcl3cinque";
        $password = "ooN5Iedi";

        $country = $_GET["id"];
 	$db = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

	// Check if a connection to the database can be established
        if(!$db){
        	echo "alert(Error: Unable to open database!)";
        }

	$actionsAnnualTotal = array();
	$actionsOverallTotal = 0;
        $actionsCounter = 0;

	// Check if a country is set or the default page is being accessed
	if ($country) {
		
		// echo "alert(Country mode)";

		if ($country == "greatbritain") {
			
		$result = pg_query($db, "SELECT COUNT(*) as count FROM fancystuff.protests WHERE country like 'UK%' GROUP BY year");
		$total = pg_query($db, "SELECT COUNT(*) as count FROM fancystuff.protests WHERE country like 'UK%'");

		} else if ($country == "europe") {
		$result = pg_query($db, "SELECT COUNT(*) as count FROM fancystuff.protests GROUP BY year");
		$total = pg_query($db, "SELECT COUNT(*) as count FROM fancystuff.protests");

                } else {
 		
		$result = pg_query($db, "SELECT COUNT(*) as count FROM fancystuff.protests WHERE lower(country)='$country' GROUP BY year");
		$total = pg_query($db, "SELECT COUNT(*) as count FROM fancystuff.protests WHERE lower(country)='$country'");
		}

		if (!$result) {
                	echo "alert(Error!)";
        	}
        	else {
			$row = pg_fetch_row($total);
			$actionsOverallTotal = $row[0];

                	while ($singleEvent = pg_fetch_row($result)) {
                		$actionsAnnualTotal[$actionsCounter] = $singleEvent[0];
                                $actionsCounter++;
			}
        	}
	}
	else {
		// echo "alert(Default mode)";
	}

	$actionsCounter = 0;
	
	$return = array("annualActions" => $actionsAnnualTotal, "overallActions" => $actionsOverallTotal);
	echo json_encode($return);		
?>
